# 🚀 Panduan Lengkap Deploy Server Multidevice Remote (PC B / VPS Oracle)

Panduan ini ditujukan untuk deployment backend **Multidevice Remote** pada VPS / PC B (Oracle Cloud, IP Publik: `168.110.216.221`).

---

## 📋 1. Ringkasan Topologi & Port

| Komponen | Domain / Target | Port | Keterangan |
|---|---|---|---|
| **Cloudflare Tunnel** | `remote.agoy507.my.id` | Forward ke `127.0.0.1:18081` | Terminating SSL/TLS di Cloudflare |
| **Caddy (vps-caddy-1)** | Loopback host | `127.0.0.1:18081` | Reverse proxy internal (loopback only) |
| **Signaling (vps-signaling-1)** | Docker internal network | `8080/tcp` | Menangani pendaftaran perangkat & SDP exchange |
| **coturn STUN/TURN** | `turn.agoy507.my.id` (`168.110.216.221`) | `3478/tcp`, `3478/udp` | Layanan STUN / TURN publik |
| **coturn Media Relay** | `168.110.216.221` | `49160-49200/udp` | Port alokasi relay WebRTC jika koneksi direct P2P gagal |

---

## 🛠️ 2. Langkah Deployment di VPS

### A. Ekstrak Berkas
Jika mengunggah `mdremote-server.zip`:
```bash
# Ekstrak arsip
unzip mdremote-server.zip
cd server
```

### B. Konfigurasi Environment (`.env`)
Salin file template `.env.example` ke `.env`:
```bash
cp .env.example .env
nano .env
```

Pastikan mengisi parameter berikut:
```ini
# Secret HMAC yang digunakan bersama antara signaling dan coturn
# Gunakan secret/password yang sama dengan yang sudah Anda buat (17 Nov)
TURN_SECRET=masukkan_secret_turn_anda_disini

# TTL kredensial TURN sementara (default 3600 detik / 1 jam)
TURN_TTL_SECONDS=3600

# Opsional: Jika ingin membatasi signaling dengan API token
SERVER_API_TOKEN=
```
Simpan file dengan `Ctrl + O`, lalu keluar dengan `Ctrl + X`.

---

## 🔥 3. Konfigurasi Firewall & Oracle Security List

> [!IMPORTANT]
> Pada **Oracle Cloud Infrastructure (OCI)**, terdapat **2 lapisan firewall**:
> 1. **Security List / Network Security Group (VCN Subnet di Web Console OCI)**
> 2. **Firewall lokal di dalam OS (firewalld / iptables)**
> Keduanya **harus** membuka port TURN agar traffic P2P WebRTC dapat masuk.

### A. Di Web Console Oracle Cloud (OCI Ingress Rules):
Buka: **Networking** > **Virtual Cloud Networks** > Pilih VCN Anda > **Security Lists** > **Default Security List** > **Add Ingress Rules**:
1. **Rule 1 (STUN/TURN Port):**
   - Source CIDR: `0.0.0.0/0`
   - IP Protocol: `TCP`
   - Destination Port Range: `3478`
2. **Rule 2 (STUN/TURN UDP):**
   - Source CIDR: `0.0.0.0/0`
   - IP Protocol: `UDP`
   - Destination Port Range: `3478`
3. **Rule 3 (TURN Media Relay UDP Range):**
   - Source CIDR: `0.0.0.0/0`
   - IP Protocol: `UDP`
   - Destination Port Range: `49160-49200`

### B. Di Terminal OS (firewalld):
Jalankan perintah berikut:
```bash
sudo firewall-cmd --permanent --zone=public --add-port=3478/tcp
sudo firewall-cmd --permanent --zone=public --add-port=3478/udp
sudo firewall-cmd --permanent --zone=public --add-port=49160-49200/udp
sudo firewall-cmd --reload

# Verifikasi port yang aktif:
sudo firewall-cmd --zone=public --list-ports
```

*(Catatan jika VPS menggunakan `iptables` bawaan Oracle Linux/Ubuntu):*
```bash
sudo iptables -I INPUT 6 -p tcp --dport 3478 -j ACCEPT
sudo iptables -I INPUT 6 -p udp --dport 3478 -j ACCEPT
sudo iptables -I INPUT 6 -p udp --dport 49160:49200 -j ACCEPT
sudo netfilter-persistent save 2>/dev/null || sudo service iptables save 2>/dev/null || true
```

---

## ☁️ 4. Konfigurasi Cloudflare Tunnel

Di dashboard Cloudflare Zero Trust (**Networks > Tunnels**):
1. Tambahkan / pastikan Public Hostname:
   - **Subdomain:** `remote`
   - **Domain:** `agoy507.my.id`
   - **Path:** (kosongkan)
   - **Type:** `HTTP`
   - **URL:** `127.0.0.1:18081`
2. Pada **Additional application settings**:
   - Tab **HTTP Settings**:
     - Aktifkan / pastikan WebSocket didukung (Cloudflare secara default mendukung WebSocket upgrade).
     - No TLS Verify: diaktifkan jika menggunakan self-signed, tapi karena target HTTP lokal `127.0.0.1:18081`, default sudah sesuai.

DNS untuk `turn.agoy507.my.id`:
- Pastikan A record untuk `turn.agoy507.my.id` mengarah ke `168.110.216.221` dengan status **DNS Only (Grey Cloud / Bypass Proxy)**, karena Cloudflare CDN standar tidak meneruskan traffic UDP/STUN/TURN non-HTTP.

---

## 🐳 5. Menjalankan Container

Jalankan Docker Compose:
```bash
# Build dan jalankan di background
docker compose up -d --build

# Periksa status container
docker compose ps
```

Container yang harus berstatus `Up`:
- `vps-caddy-1` (Listen: `127.0.0.1:18081`)
- `vps-signaling-1` (Internal docker port: `8080`)
- `vps-coturn-1` (Listen: `0.0.0.0:3478`, `0.0.0.0:49160-49200/udp`)

---

## 🔍 6. Uji & Verifikasi Layanan

### A. Uji Healthcheck Lokal:
```bash
curl http://127.0.0.1:18081/health
# Output yang diharapkan: OK
```

### B. Uji Healthcheck dari Luar (Internet):
```bash
curl -I https://remote.agoy507.my.id/health
# Output yang diharapkan: HTTP/2 200
```

### C. Uji Log Container:
```bash
# Memeriksa log signaling:
docker compose logs -f signaling

# Memeriksa log coturn:
docker compose logs -f coturn

# Memeriksa log caddy:
docker compose logs -f caddy
```

---

## 📱 7. Konfigurasi Aplikasi Client (Android & Windows)

Pengaturan default pada kode sudah disesuaikan dengan infrastruktur ini:

| Parameter | Nilai Konfigurasi |
|---|---|
| **Signaling URL** | `wss://remote.agoy507.my.id/ws` |
| **Health Check** | `https://remote.agoy507.my.id/health` |
| **STUN Server** | `stun:turn.agoy507.my.id:3478` |
| **TURN Server** | `turn:turn.agoy507.my.id:3478?transport=udp` |
| **TURN Username** | `desktopremote` |
| **Kredensial Sesi** | Dikelola otomatis secara ephemeral HMAC oleh Signaling Server |

---

## 🛑 8. Perintah Operasional Rutin

```bash
# Menghentikan server:
docker compose down

# Merestart server:
docker compose restart

# Melihat penggunaan resource:
docker stats
```
